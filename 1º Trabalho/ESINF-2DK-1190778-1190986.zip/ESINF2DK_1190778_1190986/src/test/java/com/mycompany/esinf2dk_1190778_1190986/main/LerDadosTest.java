/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.esinf2dk_1190778_1190986.main;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author raulcoelho
 */
public class LerDadosTest {
    
    public LerDadosTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of verifyNA method, of class LerDados.
     */
    @Test
    public void testVerifyNATrue() {
        System.out.println("verifyNA");
        String test = "NA";
        String expResult = "0";
        String result = LerDados.verifyNA(test);
        assertEquals(expResult, result);
    }
    
     /**
     * Test of verifyNA method, of class LerDados.
     */
    @Test
    public void testVerifyNAFalse() {
        System.out.println("verifyNA");
        String test = "1234";
        String expResult = "1234";
        String result = LerDados.verifyNA(test);
        assertEquals(expResult, result);
    }
    
}
