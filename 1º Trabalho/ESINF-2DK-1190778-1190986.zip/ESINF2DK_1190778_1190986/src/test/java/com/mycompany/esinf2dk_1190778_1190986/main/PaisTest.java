/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.esinf2dk_1190778_1190986.main;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author raulcoelho
 */
public class PaisTest {
    
    public PaisTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of compareTo method, of class Pais.
     */
    @Test
    public void testCompareToIgual() {
        System.out.println("compareToIgual");
        Pais o = new Pais("\"CHN\"","\"China\"","\"Asia\"","0","0","0","0","0","0","0","0");
        Pais instance = new Pais("\"CHN\"", "\"China\"", "\"Asia\"","0","0","0","0","0","0","0","0");
        int result = instance.compareTo(o);
        assertTrue(result == 0);
    }
    
    /**
     * Test of compareTo method, of class Pais.
     */
    @Test
    public void testCompareToNeg() {
        System.out.println("compareToNeg");
        Pais o = new Pais("\"FRA\"","\"France\"","\"Europe\"","0","0","0","0","0","0","0","0");
        Pais instance = new Pais("\"CHN\"", "\"China\"", "\"Asia\"","0","0","0","0","0","0","0","0");
        int result = instance.compareTo(o);
        assertTrue(result < 0);
    }
    
    /**
     * Test of compareTo method, of class Pais.
     */
    @Test
    public void testCompareToPos() {
        System.out.println("compareToPos");
        Pais o = new Pais("\"BRA\"","\"Brazil\"","\"South America\"","0","0","0","0","0","0","0","0");
        Pais instance = new Pais("\"CHN\"", "\"China\"", "\"Asia\"","0","0","0","0","0","0","0","0");
        int result = instance.compareTo(o);
        assertTrue(result > 0);
    }
}
