/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.esinf2dk_1190778_1190986.main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author raulcoelho
 */
public class MundoTest {

    public MundoTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getFiftyPositive method, of class Mundo.
     */
    @Test
    public void testGetFiftyPositive() {
        System.out.println("getFiftyPositive");
        Mundo instance = new Mundo();
        Pais p1 = new Pais("BRA", "Brazil", "South America", "0", "0", "0", "0", "0", "0", "0", "0");
        Pais p2 = new Pais("CHN", "China", "Asia", "0", "0", "0", "0", "0", "0", "0", "0");
        Pais p3 = new Pais("FRA", "France", "Europe", "0", "0", "0", "0", "0", "0", "0", "0");
        Pais p4 = new Pais("AFG", "Afghanistan", "Asia", "0", "0", "0", "0", "0", "0", "0", "0");

        DadosDiarios d1 = new DadosDiarios("2020-04-24", "49492", "3735", "3313", "407", "0", "0");
        DadosDiarios d2 = new DadosDiarios("2020-04-25", "52995", "3503", "3670", "357", "0", "0");

        DadosDiarios d3 = new DadosDiarios("2020-02-12", "44724", "2028", "1114", "97", "0", "0");
        DadosDiarios d4 = new DadosDiarios("2020-02-13", "59865", "15141", "1368", "254", "0", "0");

        DadosDiarios d5 = new DadosDiarios("2020-03-31", "44550", "4376", "3024", "418", "0", "0");
        DadosDiarios d6 = new DadosDiarios("2020-04-01", "52128", "7578", "3523", "499", "0", "0");

        DadosDiarios d7 = new DadosDiarios("2020-09-28", "39227", "0", "1453", "0", "0", "0");
        DadosDiarios d8 = new DadosDiarios("2020-09-29", "39239", "12", "1456", "3", "0", "0");

        ArrayList l1 = new ArrayList<>();
        l1.add(d1);
        l1.add(d2);
        instance.mundo.put(p1, l1);

        ArrayList l2 = new ArrayList<>();
        l2.add(d3);
        l2.add(d4);
        instance.mundo.put(p2, l2);

        ArrayList l3 = new ArrayList<>();
        l3.add(d5);
        l3.add(d6);
        instance.mundo.put(p3, l3);

        ArrayList l4 = new ArrayList<>();
        l4.add(d7);
        l4.add(d8);
        instance.mundo.put(p4, l4);

        Map<Pais, List<Integer>> expResult = new HashMap<>();

        ArrayList l5 = new ArrayList<>();
        l5.add(115);
        l5.add(1);
        ArrayList l6 = new ArrayList<>();
        l6.add(43);
        l6.add(1);
        ArrayList l7 = new ArrayList<>();
        l7.add(91);
        l7.add(1);

        expResult.put(p2, l6);
        expResult.put(p3, l7);
        expResult.put(p1, l5);

        assertTrue(expResult.equals(instance.getFiftyPositive()));
    }

    /**
     * Test of getNewCasesAndDeaths method, of class Mundo.
     */
    @Test
    public void testGetNewCasesAndDeaths() {
        System.out.println("getNewCasesAndDeaths");
        Mundo instance = new Mundo();
        LerDados ler = new LerDados(instance);
        List<String> expResult = Arrays.asList("Africa", "1", "0", "0", "Africa", "2", "3", "0", "Africa", "3", "5134", "166", "Africa", "4", "31598", "1425", "Africa", "5", "105535", "2480", "Africa", "6", "251824", "5807",
                "Africa", "7", "516291", "9433", "Africa", "8", "336450", "10274", "Africa", "9", "220699", "5873", "Asia", "1", "9766", "213", "Asia", "2", "73473", "2679", "Asia", "3", "86771", "3997", "Asia", "4", "337267", "11375",
                "Asia", "5", "603767", "12005", "Asia", "6", "1148151", "25589", "Asia", "7", "1957780", "39565", "Asia", "8", "2809542", "46760", "Asia", "9", "3413861", "50030", "Europe", "1", "15", "0", "Europe", "2", "1136", "23",
                "Europe", "3", "436524", "27926", "Europe", "4", "855609", "105377", "Europe", "5", "613244", "42562", "Europe", "6", "454466", "15584", "Europe", "7", "458299", "10221", "Europe", "8", "764576", "9890", "Europe", "9", "1339629", "13456",
                "North America", "1", "9", "0", "North America", "2", "75", "0", "North America", "3", "176306", "3382", "North America", "4", "952660", "63107", "North America", "5", "872349", "55701", "North America", "6", "1043615", "42897", "North America", "7", "2271190", "48876",
                "North America", "8", "1852313", "52821", "North America", "9", "1450729", "37360", "Oceania", "1", "7", "0", "Oceania", "2", "19", "0", "Oceania", "3", "5298", "21", "Oceania", "4", "2812", "95", "Oceania", "5", "503", "15", "Oceania", "6", "705", "2", "Oceania", "7", "8750", "87",
                "Oceania", "8", "11296", "432", "Oceania", "9", "3850", "312", "South America", "1", "0", "0", "South America", "2", "1", "0", "South America", "3", "12354", "305", "South America", "4", "152202", "7797", "South America", "5", "688417", "31222", "South America", "6", "1336057", "44261",
                "South America", "7", "1841061", "58034", "South America", "8", "2206025", "59364", "South America", "9", "1735437", "48690");

        List<String> result = instance.getNewCasesAndDeaths();
        assertEquals(expResult, result);
    }

    /**
     * Test of getMortesFumadores method, of class Mundo.
     */
    @Test
    public void testGetMortesFumadores() {
        System.out.println("getMortesFumadores");
        Mundo instance = new Mundo();

        Pais p1 = new Pais("CHL", "Chile", "South America", "19116209", "11.087", "127.993", "8.46", "34.2", "41.5", "2.11", "80.18");
        Pais p2 = new Pais("FRA", "France", "Europe", "65273512", "19.178", "86.06", "4.77", "30.1", "35.6", "5.98", "82.66");
        Pais p3 = new Pais("RUS", "Russia", "Europe", "145934460", "14.178", "431.297", "6.18", "23.4", "58.3", "8.05", "72.58");
        
        DadosDiarios d1 = new DadosDiarios("2020-09-28", "457901", "1922", "12641", "50", "0", "0");
        DadosDiarios d2 = new DadosDiarios("2020-09-29", "459671", "1770", "12698", "57", "0", "0");

        DadosDiarios d3 = new DadosDiarios("2020-09-01", "281205", "3082", "30635", "29", "165549", "0");
        DadosDiarios d4 = new DadosDiarios("2020-09-02", "286007", "4982", "30661", "26", "164584", "0");

        DadosDiarios d5 = new DadosDiarios("2020-09-28", "1151438", "7867", "20324", "99", "0", "0");
        DadosDiarios d6 = new DadosDiarios("2020-09-29", "1159573", "8135", "20385", "61", "0", "0");
        
        ArrayList l1 = new ArrayList<>();
        l1.add(d1);
        l1.add(d2);
        instance.mundo.put(p1, l1);

        ArrayList l2 = new ArrayList<>();
        l2.add(d3);
        l2.add(d4);
        instance.mundo.put(p2, l2);

        ArrayList l3 = new ArrayList<>();
        l3.add(d5);
        l3.add(d6);
        instance.mundo.put(p3, l3);
        
        List<Pais> expResult = Arrays.asList(p3,p1);
        List<Pais> result = instance.getMortesFumadores();
        assertEquals(expResult, result);
    }

    /**
     * Test of verificarContinente method, of class Mundo.
     */
    @Test
    public void testVerificarContinente() {
        System.out.println("verificarContinente");
        int continente = 3;
        Mundo instance = new Mundo();
        String expResult = "Europe";
        String result = instance.verificarContinente(continente);
        assertEquals(expResult, result);
    }

    /**
     * Test of verificarDiasMes method, of class Mundo.
     */
    @Test
    public void testVerificarDiasMes() {
        System.out.println("verificarDiasMes");
        int mes = 4;
        Mundo instance = new Mundo();
        int expResult = 30;
        int result = instance.verificarDiasMes(mes);
        assertEquals(expResult, result);
    }

    /**
     * Test of getCasosPositivos method, of class Mundo.
     */
    @Test
    public void testGetCasosPositivos() {
        System.out.println("getCasosPositivos");
        int mes = 9;
        int continente = 3;
        Mundo instance = new Mundo();

        Pais p1 = new Pais("ESP", "Spain", "Europe", "0", "0", "0", "0", "0", "0", "0", "0");
        Pais p2 = new Pais("FRA", "France", "Europe", "0", "0", "0", "0", "0", "0", "0", "0");
        Pais p3 = new Pais("RUS", "Russia", "Europe", "0", "0", "0", "0", "0", "0", "0", "0");

        DadosDiarios d1 = new DadosDiarios("2020-09-01", "470973", "8115", "29152", "58", "0", "0");
        DadosDiarios d2 = new DadosDiarios("2020-09-02", "479554", "8581", "29194", "42", "0", "0");

        DadosDiarios d3 = new DadosDiarios("2020-09-01", "281205", "3082", "30635", "29", "165549", "0");
        DadosDiarios d4 = new DadosDiarios("2020-09-02", "286007", "4982", "30661", "26", "164584", "0");

        DadosDiarios d5 = new DadosDiarios("2020-09-01", "995319", "4993", "17176", "83", "0", "0");
        DadosDiarios d6 = new DadosDiarios("2020-09-02", "1000048", "4729", "17299", "123", "0", "0");

        ArrayList l1 = new ArrayList<>();
        l1.add(d1);
        l1.add(d2);
        instance.mundo.put(p1, l1);

        ArrayList l2 = new ArrayList<>();
        l2.add(d3);
        l2.add(d4);
        instance.mundo.put(p2, l2);

        ArrayList l3 = new ArrayList<>();
        l3.add(d5);
        l3.add(d6);
        instance.mundo.put(p3, l3);

        instance.getCasosPositivos(mes, continente);
    }

}
