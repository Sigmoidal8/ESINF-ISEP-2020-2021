/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.esinf2dk_1190778_1190986.main;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author raulcoelho
 */
public class OrdenarPorContinenteTest {
    
    public OrdenarPorContinenteTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of compare method, of class OrdenarPorContinente.
     */
    @Test
    public void testCompareIgual() {
        System.out.println("compareIgual");
        Pais o1 = new Pais("\"CHN\"","\"China\"","\"Asia\"","0","0","0","0","0","0","0","0");
        Pais o2 = new Pais("\"JPN\"","\"Japan\"","\"Asia\"","0","0","0","0","0","0","0","0");;
        OrdenarPorContinente instance = new OrdenarPorContinente();
        int expResult = 0;
        int result = instance.compare(o1, o2);
        assertEquals(expResult, result);
    }
    
      /**
     * Test of compare method, of class OrdenarPorContinente.
     */
    @Test
    public void testCompareNeg() {
        System.out.println("compareNeg");
        Pais o1 = new Pais("\"CHN\"","\"China\"","\"Asia\"","0","0","0","0","0","0","0","0");
        Pais o2 = new Pais("\"FRA\"","\"France\"","\"Europe\"","0","0","0","0","0","0","0","0");
        OrdenarPorContinente instance = new OrdenarPorContinente();
        int result = instance.compare(o1, o2);
        assertTrue(result < 0);
    }
    
    /**
     * Test of compare method, of class OrdenarPorContinente.
     */
    @Test
    public void testComparePos() {
        System.out.println("comparePos");
        Pais o1 = new Pais("\"BRA\"","\"Brazil\"","\"South America\"","0","0","0","0","0","0","0","0");
        Pais o2 = new Pais("\"FRA\"","\"France\"","\"Europe\"","0","0","0","0","0","0","0","0");
        OrdenarPorContinente instance = new OrdenarPorContinente();
        int result = instance.compare(o1, o2);
        assertTrue(result > 0);
    } 
}
