/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.esinf2dk_1190778_1190986.main;

/**
 *
 * @author raulcoelho
 */
public class Pais implements Comparable<Pais> {

    /**
     * Código único do país
     */
    private String iso_code;
    
    /**
     * Nome do país
     */
    private String nome;
    
    /**
     * Continente em que o país está presente
     */
    private String continente;
    
    /**
     * População residente no país
     */
    private int population;
    
    /**
     * Percentagem de pessoas com mais de 65 anos
     */
    private float mais65;
    
    /**
     * Taxa de morte cardivascular
     */
    private float percentagemCardiovascular;
    
    /**
     * Prevalência da diabetes
     */
    private float diabetes;
    
    /**
     * Percentagem de mulheres fumadoras
     */
    private float mulheresFumadoras;
    
    /**
     * Percentagem de homens fumadores
     */
    private float homensFumadores;
    
    /**
     * Camas de hospital por mil pessoas
     */
    private float camaPorMil;
    
    /**
     * Esperança média de vida
     */
    private float esperancaVida;

    /**
     * Cria uma instância de Pais recebendo o iso_code, o nome, o continente, a population, o mais65,
     * a percentagemCardiovascular, a diabetes, a mulheresFumadoras, a homensFumadores, a camaPorMil
     * e a esperancaoVida por parâmetro
     * 
     * @param iso_code
     * @param nome
     * @param continente
     * @param population
     * @param mais65
     * @param percentagemCardiovascular
     * @param diabetes
     * @param mulheresFumadoras
     * @param homensFumadores
     * @param camaPorMil
     * @param esperancaoVida 
     */
    public Pais(String iso_code, String nome, String continente, String population,String mais65, String percentagemCardiovascular, 
            String diabetes, String mulheresFumadoras, String homensFumadores, String camaPorMil, String esperancaoVida) {
        this.iso_code = iso_code;
        this.nome = nome;
        this.continente = continente;
        this.population = Integer.parseInt(population);
        this.mais65 = Float.parseFloat(mais65);
        this.percentagemCardiovascular = Float.parseFloat(percentagemCardiovascular);
        this.diabetes = Float.parseFloat(diabetes);
        this.mulheresFumadoras = Float.parseFloat(mulheresFumadoras);
        this.homensFumadores = Float.parseFloat(homensFumadores);
        this.camaPorMil = Float.parseFloat(camaPorMil);
        this.esperancaVida = Float.parseFloat(esperancaoVida);
    }
    
    /**
     * @return the iso_code
     */
    public String getIso_code() {
        return iso_code;
    }

    /**
     * @param iso_code the iso_code to set
     */
    public void setIso_code(String iso_code) {
        this.iso_code = iso_code;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * 
     * @return 
     */
    public String getContinente() {
        return continente;
    }
    
     /**
     * @param continente the continente to set
     */
    public void setContinente(String continente) {
        this.continente = continente;
    }
    
    /**
     * @return the population
     */
    public int getPopulation() {
        return population;
    }

    /**
     * @param population the population to set
     */
    public void setPopulation(int population) {
        this.population = population;
    }

    /**
     * @return the mais65
     */
    public float getMais65() {
        return mais65;
    }

    /**
     * @param mais65 the mais65 to set
     */
    public void setMais65(float mais65) {
        this.mais65 = mais65;
    }

    /**
     * @return the percentagemCardiovascular
     */
    public float getPercentagemCardiovascular() {
        return percentagemCardiovascular;
    }

    /**
     * @param percentagemCardiovascular the percentagemCardiovascular to set
     */
    public void setPercentagemCardiovascular(float percentagemCardiovascular) {
        this.percentagemCardiovascular = percentagemCardiovascular;
    }

    /**
     * @return the diabetes
     */
    public float getDiabetes() {
        return diabetes;
    }

    /**
     * @param diabetes the diabetes to set
     */
    public void setDiabetes(float diabetes) {
        this.diabetes = diabetes;
    }

    /**
     * @return the mulheresFumadoras
     */
    public float getMulheresFumadoras() {
        return mulheresFumadoras;
    }

    /**
     * @param mulheresFumadoras the mulheresFumadoras to set
     */
    public void setMulheresFumadoras(float mulheresFumadoras) {
        this.mulheresFumadoras = mulheresFumadoras;
    }

    /**
     * @return the homensFumadores
     */
    public float getHomensFumadores() {
        return homensFumadores;
    }

    /**
     * @param homensFumadores the homensFumadores to set
     */
    public void setHomensFumadores(float homensFumadores) {
        this.homensFumadores = homensFumadores;
    }

    /**
     * @return the camaPorMil
     */
    public float getCamaPorMil() {
        return camaPorMil;
    }

    /**
     * @param camaPorMil the camaPorMil to set
     */
    public void setCamaPorMil(float camaPorMil) {
        this.camaPorMil = camaPorMil;
    }

    /**
     * @return the esperancaVida
     */
    public float getEsperancaVida() {
        return esperancaVida;
    }

    /**
     * @param esperancaVida the esperancaVida to set
     */
    public void setEsperancaVida(float esperancaVida) {
        this.esperancaVida = esperancaVida;
    }
    
    /**
     * Retorna a descrição textual da classe Pais
     * @return 
     */
    @Override
    public String toString() {
        return String.format("Iso_code: %s\nnome: %s\nPopulation: %s\nMais65: %s\nPercentagem Cardiovascular: %s\nDiabetes: %s\nMulheresFumadoras: %s\n"
                + "homensFumadores: %s\nEsperanca média vida: %s",getIso_code(), getNome(),  getPopulation(), getMais65(), getPercentagemCardiovascular(), 
                getDiabetes(), getMulheresFumadoras(), getHomensFumadores(), getCamaPorMil(), getEsperancaVida());
    }

    /**
     * Compara o nome do Pais com o nome de outro
     * Pais que recebe por parâmetro
     * 
     * @param o
     * @return 
     */
    @Override
    public int compareTo(Pais o) {
        return nome.compareTo(o.getNome());
    }

    
}
