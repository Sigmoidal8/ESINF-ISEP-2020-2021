/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.esinf2dk_1190778_1190986.main;

import java.util.Comparator;

/**
 *
 * @author RaulCoelho e MiguelSilva
 */
public class OrdenarPorContinente implements Comparator<Pais> {
   
    /**
     * Compara o continente de duas instâncias de 
     * País e retorna qual o maior
     * 
     * @param o1
     * @param o2
     * @return 
     */
    @Override
    public int compare(Pais o1, Pais o2) {
        return (o1.getContinente().compareTo(o2.getContinente()));
    }
}