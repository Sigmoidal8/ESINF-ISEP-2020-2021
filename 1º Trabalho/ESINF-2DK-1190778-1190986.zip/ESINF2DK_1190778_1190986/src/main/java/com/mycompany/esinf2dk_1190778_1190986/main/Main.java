/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.esinf2dk_1190778_1190986.main;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author RaulCoelho e MiguelSilva
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Mundo mundo = new Mundo();

        int scan = 1;
        while (scan != 0) {
            menu();
            scan = sc.nextInt();

            Map<Pais, List<DadosDiarios>> mapa = mundo.getContinente();

            switch (scan) {
                case 1:
                    LerDados ler = new LerDados(mundo);
                    System.out.println("Dados lidos com sucesso!!");
                    break;
                case 2:
                    Map<Pais, List<Integer>> lista = mundo.getFiftyPositive();
                    System.out.println("iso_code  continent         location              date          total cases    mindays");
                    for (Pais pais : lista.keySet()) {
                        System.out.printf("%-10s%-18s%-22s%-14s%-14d%-10d\n", pais.getIso_code(), pais.getContinente(), pais.getNome(), mapa.get(pais).get(lista.get(pais).get(1)).getDia().toString(),
                                mapa.get(pais).get(lista.get(pais).get(1)).getTotalCasos(), lista.get(pais).get(0));
                    }
                    break;
                case 3:
                    List<String> dados = mundo.getNewCasesAndDeaths();
                    System.out.println("continent         month    new_cases    new_deaths");

                    for (int k = 0; k < dados.size(); k += 4) {
                        System.out.printf("%-18s%-9d%-13d%-10d\n", dados.get(k), Integer.parseInt(dados.get(k + 1)), Integer.parseInt(dados.get(k + 2)), Integer.parseInt(dados.get(k + 3)));
                    }
                    break;

                case 4:
                    Scanner scanner = new Scanner(System.in);
                    menuMes();
                    int mes = scanner.nextInt();
                    menuContinente();
                    int continente = scanner.nextInt();
                    mundo.getCasosPositivos(mes, continente);
                    break;
                case 5:
                    List<Pais> listaMortes = mundo.getMortesFumadores();
                    for (Pais pais : listaMortes) {
                        System.out.printf("\n[%s, %.1f, %d] ", pais.getNome(), pais.getHomensFumadores() + pais.getMulheresFumadoras(), mundo.getContinente().get(pais).get(mundo.getContinente().get(pais).size() - 1).getTotalMortes());
                    }
                    System.out.println("\n");
                    break;
                case 0:
                    System.exit(0);

                default:
                    System.out.println("\nEssa opção não se encontra disponivel no menu.\nPor favor ensira uma nova opção.\n");

            }
        }
    }

    /**
     * Menu Principal
     */
    private static void menu() {
        System.out.println("\n\tMENU");
        System.out.println("====================================================================================================================================");
        System.out.println("Qual das seguintes funções deseja fazer?");
        System.out.println("1-Carregar ficheiro de texto");
        System.out.println("2-Apresentar países ordenados por ordem crescente do número mínimo de dias que foi necessário para atingir os 50.000 casos positivos.");
        System.out.println("3-Apresentar o total de novos casos/novas mortes por continente/mês");
        System.out.println("4-Selecionar um dia e verificar os casos para determinado continente");
        System.out.println("5-Apresentar todos os países com mais de 70% de fumadores, ordenados por ordem decrescente do número de novas mortes");
        System.out.println("0-Sair");
        System.out.println("====================================================================================================================================\n");

    }

    /**
     * Menu que apresenta os meses
     */
    private static void menuMes() {
        System.out.println("\n\tMENU");
        System.out.println("======================");
        System.out.println("Qual mês deseja?");
        System.out.println("1-Janeiro");
        System.out.println("2-Fevereiro");
        System.out.println("3-Março");
        System.out.println("4-Abril");
        System.out.println("5-Maio");
        System.out.println("6-Junho");
        System.out.println("7-Julho");
        System.out.println("8-Agosto");
        System.out.println("9-Setembro");
        System.out.println("======================\n");

    }

    /**
     * Menu que apresenta os continentes
     */
    private static void menuContinente() {
        System.out.println("\n\tMENU");
        System.out.println("======================");
        System.out.println("Qual continente deseja?");
        System.out.println("1-África");
        System.out.println("2-Asia");
        System.out.println("3-Europa");
        System.out.println("4-América do Norte");
        System.out.println("5-Oceânia");
        System.out.println("6-América do Sul");
        System.out.println("======================\n");

    }
}
