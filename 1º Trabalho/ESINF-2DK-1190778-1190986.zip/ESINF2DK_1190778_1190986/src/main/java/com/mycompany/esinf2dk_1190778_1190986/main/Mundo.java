/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.esinf2dk_1190778_1190986.main;

import java.time.LocalDate;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @author RaulCoelho e MiguelSilva
 */
public class Mundo {

    /**
     * Map que guarda instâncias da classe País e associa-os a um ArrayList com
     * instâncias da classe DadosDiarios
     */
    Map<Pais, List<DadosDiarios>> mundo;

    /**
     * Cria uma instância da classe mundo iniciando o seu map
     */
    public Mundo() {
        mundo = new TreeMap<Pais, List<DadosDiarios>>();
    }

    /**
     * Retorna um map de países associando-o a um ArrayList de inteiros que
     * guarda o número de dias que o Pais demorou a atingir 50000 casos
     * positivos e a posição em que tal acontence
     *
     * @return
     */
    public Map<Pais, List<Integer>> getFiftyPositive() {
        Map<Pais, List<Integer>> listaOrdenada = new HashMap<>();
        for (Pais pais : mundo.keySet()) {
            LocalDate diaInicio = LocalDate.of(2020, 1, 1);
            long dias = 0;
            int i = 0;
            for (DadosDiarios dados : mundo.get(pais)) {
                if (dados.getTotalCasos() > 50000) {
                    dias = dados.getDia().getLong(ChronoField.DAY_OF_YEAR) - diaInicio.getLong(ChronoField.DAY_OF_YEAR);
                    listaOrdenada.put(pais, new ArrayList<>());
                    listaOrdenada.get(pais).add((int) dias);
                    listaOrdenada.get(pais).add(i);
                    break;
                }
                i++;
            }
        }
        listaOrdenada = sortByValue(listaOrdenada);
        return listaOrdenada;
    }

    /**
     *Ordena um Map de Pais com um List de Integer pelo o primeiro valor
     * guardado no List
     * 
     * @param listaOrdenada
     * @return
     */
    private static Map<Pais, List<Integer>> sortByValue(Map<Pais, List<Integer>> listaOrdenada) {
        List<Map.Entry<Pais, List<Integer>>> list = new LinkedList<Map.Entry<Pais, List<Integer>>>(listaOrdenada.entrySet());

        Collections.sort(list, new Comparator<Map.Entry<Pais, List<Integer>>>() {
            public int compare(Map.Entry<Pais, List<Integer>> o1, Map.Entry<Pais, List<Integer>> o2) {
                return (o1.getValue().get(0)).compareTo(o2.getValue().get(0));
            }
        });

        Map<Pais, List<Integer>> sortedMap = new LinkedHashMap<Pais, List<Integer>>();
        for (Map.Entry<Pais, List<Integer>> entry : list) {
            sortedMap.put(entry.getKey(), new ArrayList<>());
            sortedMap.get(entry.getKey()).add(entry.getValue().get(0));
            sortedMap.get(entry.getKey()).add(entry.getValue().get(1));
        }
        return sortedMap;
    }

    /**
     * Retora um List de String com a descrição ordenada dos continentes
     * por mês e com os novos casos e novas mortes para cada mês
     * 
     * @return 
     */
    public List<String> getNewCasesAndDeaths() {
        List<Pais> listaContinentes_Mes = new ArrayList<>();
        for (Pais pais : mundo.keySet()) {
            listaContinentes_Mes.add(pais);
        }
        Collections.sort(listaContinentes_Mes, new OrdenarPorContinente());

        List<String> listaDados = getNewCasesAndDeathsList(listaContinentes_Mes);

        return listaDados;
    }

    /**
     * Recebe um List de Pais que verifica para cada mês e para cada
     * continente qual o número de novos casos e novas mortes e
     * retorna os dados dentro de um Array de String
     * 
     * @param listaContinentes_Mes
     * @return 
     */
    public List<String> getNewCasesAndDeathsList(List<Pais> listaContinentes_Mes) {
        Pais pais = listaContinentes_Mes.get(0);
        String continente = pais.getContinente();
        List<String> listaDados = new ArrayList<>();
        int totalNovosCasos = 0;   
        int totalNovasMortes = 0;
        int mes = 1;  
        int posicaoPais = 0;                                  //Posição do último país usado  
        int primeiroPaisPorContinente = 0;                //Posição do primeiro país do continente atual no array

        while (posicaoPais < listaContinentes_Mes.size()) {         //verifica se a posição do país ainda faz parte da lista
            pais = listaContinentes_Mes.get(posicaoPais);
            while (pais.getContinente().equalsIgnoreCase(continente)) {    
                for (DadosDiarios dados : mundo.get(pais)) {
                    if (dados.getDia().getMonthValue() == mes) {
                        totalNovosCasos += dados.getNovosCasos();
                        totalNovasMortes += dados.getNovasMortes();
                    }
                }
                posicaoPais++;                                              //Avança para a posição do próximo país da lista 
                if (posicaoPais == listaContinentes_Mes.size()) {          //Se a posição for superior ao tamanho da lista sai do ciclo
                    break;
                }
                pais = listaContinentes_Mes.get(posicaoPais);           //Passa ao país seguinte
            }
            listaDados.add(listaContinentes_Mes.get(posicaoPais - 1).getContinente());  //Adiciona os dados pedidos do continente anterior
            listaDados.add(String.valueOf(mes));
            listaDados.add(String.valueOf(totalNovosCasos));
            listaDados.add(String.valueOf(totalNovasMortes));
            if (mes == 9) {                                                 
                mes = 1;
                primeiroPaisPorContinente = posicaoPais;                //Atribui a posição do primeiro país do continente atual
                continente = pais.getContinente();
            } else {
                mes++;
                posicaoPais = primeiroPaisPorContinente;                //Volta a pôr o posicaoPais no primeiro país do continenteS
            }
            totalNovosCasos = 0;
            totalNovasMortes = 0;
        }
        return listaDados;
    }

    /**
     * Recebe um mes e um continente por parâmetro e verifica
     * para esses casos qual o número de novos casos por dia para 
     * cada País desse continente e ordena-o em ordem decrescente
     * e apresenta na consola
     * 
     * @param mes
     * @param continente 
     */
    public void getCasosPositivos(int mes, int continente) {
        List<Pais> paisesAUsar = new ArrayList<>();
        String cont = verificarContinente(continente);
        int nrDias = verificarDiasMes(mes);

        for (Pais pais : mundo.keySet()) {
            if (pais.getContinente().equals(cont)) {
                paisesAUsar.add(pais);
            }
        }
        int dia = 1;
        Map<Pais, Integer> mapa = new HashMap<>();
        while (dia <= nrDias) {
            for (Pais pais : paisesAUsar) {
                for (DadosDiarios dados : mundo.get(pais)) {
                    if (dados.getDia().getMonthValue() == mes) {
                        if (dados.getDia().getDayOfMonth() == dia) {
                            mapa.put(pais, dados.getNovosCasos());
                        }
                    }
                }
            }
            System.out.printf("Dia %d -->", dia);

            HashMap<Pais, Integer> temp = sortByValue2(mapa);

            for (Pais pais : temp.keySet()) {
                System.out.printf("\t%s (%d)\n", pais.getNome(), temp.get(pais));
            }
            dia++;
            mapa.clear();
            temp.clear();
        }
    }

    /**
     * Recebe um Map de Pais e Integer e ordena-o pelo valor
     * do Integer
     * 
     * @param mapa
     * @return 
     */
    private static HashMap<Pais, Integer> sortByValue2(Map<Pais, Integer> mapa) {

        List<Map.Entry<Pais, Integer>> list = new LinkedList<Map.Entry<Pais, Integer>>(mapa.entrySet());

        Collections.sort(list, new Comparator<Map.Entry<Pais, Integer>>() {
            @Override
            public int compare(Map.Entry<Pais, Integer> o1, Map.Entry<Pais, Integer> o2) {
                return (o2.getValue() - o1.getValue());
            }
        });
        HashMap<Pais, Integer> temp = new LinkedHashMap<Pais, Integer>();
        for (Map.Entry<Pais, Integer> aa : list) {
            temp.put(aa.getKey(), aa.getValue());
        }
        return temp;
    }

    /**
     * Retorna uma lista de países com mais de 70% de fumadores
     * ordenado pelo número de novos mortos
     * 
     * @return 
     */
    public List<Pais> getMortesFumadores() {
        List<Pais> lista = new ArrayList<>();
        for (Pais pais : mundo.keySet()) {
            if (pais.getHomensFumadores() + pais.getMulheresFumadoras() > 70) {
                lista.add(pais);
            }
        }
        Collections.sort(lista, new Comparator<Pais>() {
            @Override
            public int compare(Pais o1, Pais o2) {
                return mundo.get(o2).get(mundo.get(o2).size() - 1).getTotalMortes() - mundo.get(o1).get(mundo.get(o1).size() - 1).getTotalMortes();
            }
        });
        return lista;
    }

    /**
     * Recebe um int da posição do continente e retorna
     * o seu nome
     * 
     * @param continente
     * @return 
     */
    public String verificarContinente(int continente) {
        switch (continente) {
            case (1):
                return "Africa";
            case (2):
                return "Asia";
            case (3):
                return "Europe";
            case (4):
                return "North America";
            case (5):
                return "Oceania";
            case (6):
                return "South America";
        }
        return null;
    }

    /**
     * Recebe o int do mês e retorna o seu número de 
     * dias1
     * 
     * @param mes
     * @return 
     */
    public int verificarDiasMes(int mes) {
        switch (mes) {
            case (1):
                return 31;
            case (2):
                return 29;
            case (3):
                return 31;
            case (4):
                return 30;
            case (5):
                return 31;
            case (6):
                return 30;
            case (7):
                return 31;
            case (8):
                return 30;
            case (9):
                return 29;
        }
        return 0;
    }

    /**
     * Retorna o map de paises e dados diários
     *
     * @return
     */
    public Map<Pais, List<DadosDiarios>> getContinente() {
        return mundo;
    }

}
