/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.esinf2dk_1190778_1190986.main;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author RaulCoelho e MiguelSilva
 */
public class LerDados {

    /**
     * Nome do ficheiro a ler
     */
    private static final String ficheiro = "owid-covid-data.csv";

    /**
     * Recebe uma instância de mundo e preenche o seu map com os dados
     * retirados do ficheiro
     * 
     * @param mundo 
     */
    public LerDados(Mundo mundo) {
        boolean novo = true;
        Map<Pais, List<DadosDiarios>> dadosMundo = mundo.getContinente();
        try {
            Scanner sc = new Scanner(new File(ficheiro));
            sc.nextLine();
            while (sc.hasNextLine()) {
                novo = true;
                String linha = sc.nextLine();
                String itens[] = linha.split(",");
                for (Pais pais : dadosMundo.keySet()) {
                    if (pais.getIso_code().equals(itens[0].substring(1,itens[0].length()-1))) {
                        List<DadosDiarios> dados = dadosMundo.get(pais);
                        dados.add(new DadosDiarios(verifyNA(itens[3]), verifyNA(itens[4]), verifyNA(itens[5]), verifyNA(itens[6]),
                                verifyNA(itens[7]), verifyNA(itens[8]), verifyNA(itens[9])));
                        novo = false;
                        break;
                    }
                }
                if (novo == true) {
                    Pais novoPais = new Pais(itens[0].substring(1,itens[0].length()-1), itens[2].substring(1,itens[2].length()-1), itens[1].substring(1,itens[1].length()-1),
                    verifyNA(itens[10]),verifyNA(itens[11]),verifyNA(itens[12]),verifyNA(itens[13]),verifyNA(itens[14]),
                            verifyNA(itens[15]), verifyNA(itens[16]), verifyNA(itens[17]));
                    dadosMundo.put(novoPais, new ArrayList<>());
                    List<DadosDiarios> dados = dadosMundo.get(novoPais);
                    dados.add(new DadosDiarios(verifyNA(itens[3]), verifyNA(itens[4]), verifyNA(itens[5]), 
                            verifyNA(itens[6]), verifyNA(itens[7]), verifyNA(itens[8]), verifyNA(itens[9])));
                }
            }
        } catch (FileNotFoundException fnf) {
            System.out.println("Ficheiro não encontrado.");
        }
    }
    
    /**
     * Verifica se a string que vêm por parâmetro é igual a NA, se for retorna 0,
     * se não for retorna a própria string.
     * 
     * @param test
     * @return 
     */
    public static String verifyNA(String test){
        if(!test.equals("NA")){
            return test;
        }else{
            return "0";
        }
    }
}
