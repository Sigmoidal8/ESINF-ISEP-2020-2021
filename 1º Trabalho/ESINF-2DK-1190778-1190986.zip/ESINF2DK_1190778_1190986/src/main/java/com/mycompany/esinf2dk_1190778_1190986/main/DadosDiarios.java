/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.esinf2dk_1190778_1190986.main;

import java.time.LocalDate;

/**
 *
 * @author RaulCoelho e MiguelSilva
 */
public class DadosDiarios {

    /**
     * Dia do dado
     */
    private LocalDate dia;
    
    /**
     * Total de casos até ao dia
     */
    private int totalCasos;
    
    /**
     * Número de novos casos no dia
     */
    private int novosCasos;
    
    /**
     * Total de mortes até ao dia
     */
    private int totalMortes;
    
    /**
     * Número de novas mortes no dia;
     */
    private int novasMortes;
    
    /**
     * Número de novos testados no dia;
     */
    private int novosTestados;
    
    /**
     * Total de testados até ao dia
     */
    private int totalTestados;
  
    /**
     * Construtor que recebe o dia, o total de casos, os novos casos, o total de mortes, as novas mortes, 
     * os novos testados e o total de testados por parâmetro e cria uma instância de DadosDiarios.
     * 
     * @param dia
     * @param totalCasos
     * @param novosCasos
     * @param totalMortes
     * @param novasMortes
     * @param novosTestados
     * @param totalTestados 
     */
    public DadosDiarios(String dia, String totalCasos, String novosCasos, String totalMortes, String novasMortes, String novosTestados, String totalTestados) {
        
        if (dia!=null) {
            String data[] = dia.split("-");
            this.dia = LocalDate.of(Integer.parseInt(data[0]), Integer.parseInt(data[1]), Integer.parseInt(data[2]));
        }
        this.totalCasos = Integer.parseInt(totalCasos);
        this.novosCasos = Integer.parseInt(novosCasos);
        this.totalMortes = Integer.parseInt(totalMortes);
        this.novasMortes = Integer.parseInt(novasMortes);
        this.novosTestados = Integer.parseInt(novosTestados);
        this.totalTestados = Integer.parseInt(totalTestados);
    }

    /**
     * @return the dia
     */
    public LocalDate getDia() {
        return dia;
    }

    /**
     * @param dia the dia to set
     */
    public void setDia(LocalDate dia) {
        this.dia = dia;
    }

    /**
     * @return the totalCasos
     */
    public int getTotalCasos() {
        return totalCasos;
    }

    /**
     * @param totalCasos the totalCasos to set
     */
    public void setTotalCasos(int totalCasos) {
        this.totalCasos = totalCasos;
    }

    /**
     * @return the novosCasos
     */
    public int getNovosCasos() {
        return novosCasos;
    }

    /**
     * @param novosCasos the novosCasos to set
     */
    public void setNovosCasos(int novosCasos) {
        this.novosCasos = novosCasos;
    }

    /**
     * @return the totalMortes
     */
    public int getTotalMortes() {
        return totalMortes;
    }

    /**
     * @param totalMortes the totalMortes to set
     */
    public void setTotalMortes(int totalMortes) {
        this.totalMortes = totalMortes;
    }

    /**
     * @return the novasMortes
     */
    public int getNovasMortes() {
        return novasMortes;
    }

    /**
     * @param novasMortes the novasMortes to set
     */
    public void setNovasMortes(int novasMortes) {
        this.novasMortes = novasMortes;
    }

    /**
     * @return the novosTestados
     */
    public int getNovosTestados() {
        return novosTestados;
    }

    /**
     * @param novosTestados the novosTestados to set
     */
    public void setNovosTestados(int novosTestados) {
        this.novosTestados = novosTestados;
    }

    /**
     * @return the totalTestados
     */
    public int getTotalTestados() {
        return totalTestados;
    }

    /**
     * @param totalTestados the totalTestados to set
     */
    public void setTotalTestados(int totalTestados) {
        this.totalTestados = totalTestados;
    }

    /**
     * Retorna a descrição textual da classe DadosDiarios
     * 
     * @return 
     */
    public String toString(){
        return String.format("Data: %s\nTotal de casos: %s\nNovos Casos: %s\nTotal de Mortes: %s\nNovas Mortes: %s\nNovos Testados: %s\n"
                + "Total Testados: %s", getDia(), getTotalCasos(), getNovosCasos(), getTotalMortes(), getNovasMortes(), getNovosTestados(), getTotalTestados());
    }

    
}
